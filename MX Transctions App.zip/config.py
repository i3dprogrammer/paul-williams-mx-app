#########################
# Core Configuration
#########################
HOST_DEV = "https://int-api.mx.com"
HOST_PROD = "https://api.mx.com"
CLIENT_ID = "8f5d6488-d32b-40c3-a32d-3de58790e7c7"
API_KEY = "3dc026d036ccf2d37f62d39ec7cf9bc06d1c6f7a"